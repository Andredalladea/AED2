#include <stdio.h>
#include <stdlib.h>
#include "tudo.h"
#include <string.h>

int main() {
     int qu;
     int *tot;
    scanf("%d",&qu);
    tot = (int*) calloc(qu, sizeof(int));
    for(int u=0;u<qu;u++){
   //declara  o de variaveis
	t_pilha P;
	int *cont;
	int *pos;
	int *fos;
	int *los;
	pos = (int*) calloc(2, sizeof(int));
    pos[1] = 0;
    fos = (int*) calloc(2, sizeof(int));
    fos[1] = 0;
    cont = (int*) calloc(2, sizeof(int));
    cont[1] = 0;
    //aloca  o de espa o
	int x;
	int z;
	int j;
    int tam;
	int n, m;
    char str1[] = "i";
    int r;
    int ins = 0;
    int rem = 0;
     fila_t* f = nova_fila();
    scanf("%d",&tam);
    //tamanho total
     int var = tam;
    los = (int*) calloc(tam, sizeof(int));
    inicializar(&P);
    int v = 0;
    int k = 0;
    int h = 0;
    int q;
    for(int i=0;i<tam;i++){
       char let;
        scanf(" %c", &let);
        if (let == 'i') {
        scanf("%d", &ins);
        push(ins, &P);
        enfileirar(f, ins);
        }
        else{
        scanf("%d",&rem);
        fos[1] = rem;
         //ver se e possivel fazer remocao da fila e da pilha, se possivel realizar nos dois e com isso verificar se e pilha ou fila
        possivelpopar(&P,fos);
        if(fos[1] == 8){
         x = pop(&P);
        }
        pos[1] = rem;
        //verificar se   possivel
        possiveldesenfileirar(f,pos);
        if(pos[1] == 6){
        desenfileirar(f,cont);
        }
        }
        //impossivel
        if(pos[1]==7&&fos[1]==9){
            los[i]= 1;
            z = 12;
        }
        //indefinido
        else if(pos[1]==6&&fos[1]==8){
            los[i] = 2;
        }
        //fila
        else if(pos[1] == 6){
            los[i] = 4;
        }
        //pilha
        else if(fos[1] == 8){
            los[i] = 3;
        }
        if(z==12){
            los[i]  = 1;
        }
    }
    z=0;
      //passar as variaveis para um total, para comparacao no final
    for(int j=0;j<tam;j++){
        if(los[j] == 1){
            tot[1] = 1;
        }
        else if(los[j] == 3){
            tot[1] = 3;
        }
        else if(los[j] == 4){
            tot[1] = 4;
        }
        else {
            tot[1] = 2;
        }
        for(int i=0;i<tam;i++){
        if(los[j] == 3 && los[i] == 4){
            tot[1] = 1;
        }
        if(los[j] == 4 && los[i] == 3){
            tot[1] = 1;
        }
    }
     //se for indefinido e depois se apresentar como uma fila ou uma pilha isso saira no final
    for(int i=0;i<tam;i++){
    if(tot[1] == 2 && los[i] == 4){
            if(tot[1]!=1){
        tot[1] = 4;
            }
    }
    if(tot[1] == 2 && los[i] == 3){
            if(tot[1]!=1){
        tot[1] = 3;
    }
    }
    }
    }
     //print do que e cada insercao
    if(tot[1] == 2){
    printf("indefinido\n");
    }
    else if(tot[1] == 3){
    printf("pilha\n");
    }
    else if(tot[1] == 1){
    printf("impossivel\n");
    }
    else if(tot[1] == 4){
    printf("fila\n");
    }
    }
}
