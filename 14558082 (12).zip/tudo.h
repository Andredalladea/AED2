#ifndef TUDO_H_INCLUDED
#define TUDO_H_INCLUDED
#define SUCESSO 1
#define NAO_EXISTE -1
#define JA_EXISTE -2
#define INVALIDO -3
#define CHEIA -4
#define VAZIA -5
#define MAX 128
typedef struct no no_t;

no_t* novo_no(int valor);

typedef struct fila fila_t;

fila_t* nova_fila();
void libera_fila(fila_t* f);
void enfileirar(fila_t* f, int valor);
void desenfileirar(fila_t* f,int *cont);
int vaziaa(fila_t* f);
void imprimir(fila_t* f);
void possiveldesenfileirar(fila_t* f, int *pos);

typedef struct {
	int topo;
	int pilha[MAX];
} t_pilha;

void inicializar(t_pilha *P);
int push(int e, t_pilha *P);
int pop(t_pilha *P);
int vazia(t_pilha *P);
int cheia(t_pilha *P);
int topo(t_pilha *P);
int contar(t_pilha *P);
void possivelpopar(t_pilha *P,int *fos);
void libera_pilha(t_pilha *P);

#endif
