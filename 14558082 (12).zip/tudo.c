#include <stdio.h>
#include <stdlib.h>
#include "tudo.h"

int cheia(t_pilha *P) {
    return (P->topo == MAX - 1) ? 1 : 0;
}

struct no {
    no_t* proximo;
    int valor;
};

no_t* novo_no(int valor) {
    no_t* n = malloc(sizeof(no_t));

    n->proximo = NULL;
    n->valor = valor;

    return n;
}

struct fila {
    no_t* inicio;
    no_t* fim;
};

fila_t* nova_fila() {
    fila_t* f = malloc(sizeof(fila_t));

    f->inicio = f->fim = NULL;

    return f;
}

void libera_fila(fila_t* f) {
    no_t* n = f->inicio;
    while (n != NULL) {
        no_t* temp = n;
        n = n->proximo;
        free(temp);
    }
    free(f);
}

int vaziaa(fila_t* f) {
    return f->inicio == NULL;
}

void enfileirar(fila_t* f, int valor) {
    no_t* n = novo_no(valor);

    if (vaziaa(f)) {
        f->inicio = n;
    } else {
        f->fim->proximo = n;
    }

    f->fim = n;
}



void imprimir(fila_t* f) {
    no_t* n = f->inicio;

    printf("[");
    while (n != NULL) {
        printf("%d", n->valor);
        n = n->proximo;

        if (n != NULL) printf(", ");
    }
    printf("]\n");
}
void desenfileirar(fila_t* f,int *cont) {
    if (vaziaa(f)) {
        return;
    }

    no_t* n = f->inicio;

    if (f->inicio == f->fim) {
        f->inicio = NULL;
        f->fim = NULL;
        cont[1] = n->valor;
    } else {
         cont[1] = n->valor;
        f->inicio = n->proximo;
    }
}
void possiveldesenfileirar(fila_t* f, int *pos) {
    no_t* n = f->inicio;
    if (n != NULL && pos[1] == n->valor) {
        pos[1] = 6;
    } else {
        pos[1] = 7;
    }
}

void inicializar(t_pilha *P) {
	P->topo = -1;
}


int push(int e, t_pilha *P) {

	if (cheia(P)) {
		printf("Pilha cheia\n");
		return CHEIA;
	}

	P->topo++;
	P->pilha[P->topo] = e;

	return SUCESSO;

}


void libera_pilha(t_pilha *P){
    while(!vazia(P)){
        pop(P);
    }
}






int pop(t_pilha *P) {

	if (vazia(P)) {
		printf("Nao pode popar\n");
		return VAZIA;
	}

	int e = P->pilha[P->topo];
	P->topo--;

	return e;

}
void possivelpopar(t_pilha *P,int *fos){
     if(fos[1] == P->pilha[P->topo]){
        fos[1] = 8;
     }
     else {
        fos[1] = 9;
     }
}

int vazia(t_pilha *P) {
	if (P->topo < 0) {
		return 1;
	} else {
		return 0;
	}
}

int cheiaa(t_pilha *P) {
	// return (P->topo == MAX - 1) ? 1 : 0;
	// return P->topo == MAX -1;
	if (P->topo == MAX - 1) {
		return 1;
	} else {
		return 0;
	}
}

int topo(t_pilha *P) {

	if (vazia(P)) {
		printf("Nao tem topo!!!!\n");
		return VAZIA;
	}
	return P->pilha[P->topo];

}


int contar(t_pilha *P) {
	return P->topo + 1;
}

